import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import Sidebar from '../../components/sidebar/Sidebar';
import Navbar from '../../components/navbar/Navbar';
import EditDataBox from '../../components/editableDataBox/EditDataBox';
import PeopleButton from '../../components/peopleButton/PeopleButton';
import Datatable from '../../components/datatable/Datatable';
import './campaign_details.scss';
import { Box, CircularProgress, Alert, Snackbar, Alert as MuiAlert } from '@mui/material';
import api from '../../api/axios';

const Campaign_details = () => {
  const { id } = useParams();
  const [campaign, setCampaign] = useState(null);
  const [activeTable, setActiveTable] = useState(null);
  const [tableRows, setTableRows] = useState([]);
  const [tableTitle, setTableTitle] = useState('');
  const [loading, setLoading] = useState(true);
  const [tableLoading, setTableLoading] = useState(false);
  const [error, setError] = useState(null);
  const [successMsg, setSuccessMsg] = useState('');

  // جلب بيانات الحملة
  const fetchCampaignDetails = async () => {
    if (!id) return;
    setLoading(true);
    try {
      const response = await api.get(`/campaigns/${id}`); // نفس الرابط لكل الحملات
      if (response.data?.data) {
        const apiData = response.data.data;
        setCampaign({
          id: apiData.id,
          title: apiData.title,
          description: apiData.description,
          target_amount: parseFloat(apiData.goal_amount),
          collected_amount: parseFloat(apiData.collected_amount),
          status: apiData.status, // archived أو active
          image: apiData.image ? `http://localhost:8000/storage/${apiData.image}` : 'https://via.placeholder.com/300',
          progress: Math.round((apiData.collected_amount / apiData.goal_amount) * 100),
          start_date: apiData.start_date,
          end_date: apiData.end_date,
        });
      } else {
        setError('⚠️ لم يتم العثور على بيانات الحملة');
      }
    } catch (err) {
      console.error('Error fetching campaign:', err);
      setError('فشل تحميل تفاصيل الحملة');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCampaignDetails();
  }, [id]);

  // جلب بيانات الجدول عند الضغط على الزر
  const handleButtonClick = async (type) => {
    if (type === activeTable) {
      setActiveTable(null);
      return;
    }

    if (!id) return;
    setActiveTable(type);
    setTableLoading(true);
    setTableRows([]);
    setTableTitle('');

    try {
      let response;
      if (type === 'beneficiaries') {
        response = await api.get(`/campaigns/${id}/getBeneficiaries`);
      } else if (type === 'volunteers') {
        response = await api.get(`/campaigns/${id}/getVolunteers`);
      } else if (type === 'donators') {
        response = await api.get(`/campaigns/${id}/getDonators`);
      }

      const data = response.data?.data || [];
      setTableRows(data.map((item, index) => ({ id: item.id || index, ...item })));

      const titleMap = {
        beneficiaries: 'المستفيدون',
        volunteers: 'المتطوعون',
        donators: 'المتبرعون',
      };
      setTableTitle(titleMap[type]);
    } catch (err) {
      console.error('Error fetching table data:', err);
      setTableRows([]);
    } finally {
      setTableLoading(false);
    }
  };

  // تحديث الحملة (غير مؤرشفة فقط)
  const handleUpdateCampaign = async (updatedData) => {
    if (campaign?.status === 'archived') {
      setError('❌ لا يمكن تعديل حملة مؤرشفة');
      return;
    }

    try {
      const response = await api.put(`/campaigns/update/${id}`, updatedData);
      if (response.data?.status === 200) {
        setSuccessMsg('تم تحديث الحملة بنجاح ✅');
        fetchCampaignDetails();
      }
    } catch (err) {
      console.error('Error updating campaign:', err);
      setError('فشل تحديث الحملة ❌');
    }
  };

  const tableColumnsMap = {
    beneficiaries: [
      { field: 'id', headerName: 'ID', width: 70 },
      { field: 'name', headerName: 'الاسم', width: 150 },
      { field: 'phone', headerName: 'الهاتف', width: 130 },
    ],
    volunteers: [
      { field: 'id', headerName: 'ID', width: 70 },
      { field: 'name', headerName: 'الاسم', width: 150 },
      { field: 'skills', headerName: 'المهارات', width: 200 },
    ],
    donators: [
      { field: 'id', headerName: 'ID', width: 70 },
      { field: 'name', headerName: 'الاسم', width: 150 },
      { field: 'amount', headerName: 'المبلغ', width: 120 },
    ]
  };

  if (loading) return <Box sx={{ display: 'flex', justifyContent: 'center', mt: 4 }}><CircularProgress /></Box>;
  if (error) return <Box sx={{ p: 3 }}><Alert severity="error">{error}</Alert></Box>;
  if (!campaign) return <Box sx={{ p: 3 }}><Alert severity="warning">لم يتم العثور على الحملة</Alert></Box>;

  return (
    <div className='campaign_details'>
      <Sidebar />
      <div className="campaign_detailsContainer">
        <Navbar />
        
        {/* 🔒 منع التعديل إذا كانت مؤرشفة */}
        <EditDataBox campaign={campaign} onUpdate={handleUpdateCampaign} disableEdit={campaign?.status === 'archived'} />

        <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 4, gap: 2 }}>
          <PeopleButton 
            label="المستفيدون" 
            count={activeTable === 'beneficiaries' ? tableRows.length : 0} 
            onClick={() => handleButtonClick('beneficiaries')} 
            active={activeTable === 'beneficiaries'} 
          />
          <PeopleButton 
            label="المتطوعون" 
            count={activeTable === 'volunteers' ? tableRows.length : 0} 
            onClick={() => handleButtonClick('volunteers')} 
            active={activeTable === 'volunteers'} 
          />
          <PeopleButton 
            label="المتبرعون" 
            count={activeTable === 'donators' ? tableRows.length : 0} 
            onClick={() => handleButtonClick('donators')} 
            active={activeTable === 'donators'} 
          />
        </Box>

        {activeTable && (
          <Box sx={{ mt: 3 }}>
            {tableLoading ? (
              <Box sx={{ display: 'flex', justifyContent: 'center', mt: 2 }}>
                <CircularProgress />
              </Box>
            ) : tableRows.length === 0 ? (
              <Alert severity="info">لا توجد بيانات لعرضها</Alert>
            ) : (
              <Datatable 
                title={tableTitle} 
                columns={tableColumnsMap[activeTable]} 
                rows={tableRows} 
              />
            )}
          </Box>
        )}
      </div>

      <Snackbar open={!!successMsg} autoHideDuration={3000} onClose={() => setSuccessMsg('')}>
        <MuiAlert onClose={() => setSuccessMsg('')} severity="success" sx={{ width: '100%' }}>
          {successMsg}
        </MuiAlert>
      </Snackbar>
    </div>
  );
};

export default Campaign_details;
