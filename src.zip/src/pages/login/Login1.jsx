import './login.scss';
import { Link, useNavigate } from 'react-router-dom';
import { useState } from 'react';
import axios from 'axios';

function App() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  const handleLogin = async () => {
    try {
      const response = await axios.post("http://localhost:8000/api/admin/login", {
        email,
        password,
      });

      
      const token = response.data.token;

      
      localStorage.setItem("token", token);

      
      navigate("/home");
    } catch (err) {
      if (err.response) {
        setError(err.response.data.message || "Login failed");
      } else {
        setError("Something went wrong, please try again.");
      }
    }
  };

  return (
    <div className='login-container'>
      <div className='login-box'>
        <div className="form-side">
          <div className="input-group">
            <div>
              <label htmlFor='email'>Email</label>
              <input
                type="email"
                id="email"
                placeholder="Email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
            <div>
              <label htmlFor='password'>Password</label>
              <input
                type="password"
                id="password"
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>
            <Link to="/forgot-password" className="forgot">forget password?</Link>

            {error && <p className="error-message">{error}</p>}

            <button className='login-btn' onClick={handleLogin}>
              Login
            </button>
          </div>
        </div>
        <div className="logo-side">
          <img src="/assets/Kun_aonan.jpg" alt="logo" className="Logo" />
        </div>
      </div>
    </div>
  );
}

export default App;
