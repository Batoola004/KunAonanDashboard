import React from 'react'
import "./new.scss"

const New = () => {
  return (
    <div className='new'>
        New 
    </div>
  )
}

export default New