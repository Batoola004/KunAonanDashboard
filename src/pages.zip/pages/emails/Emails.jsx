import React from 'react'
import './emails.scss'
const Emails = () => {
  return (
    <div>Emails</div>
  )
}

export default Emails