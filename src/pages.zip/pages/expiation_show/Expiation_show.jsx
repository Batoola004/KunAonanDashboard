import React from 'react'
import Sidebar from '../../components/sidebar/Sidebar'
import Navbar from '../../components/navbar/Navbar'
import Filter from '../../components/filters/Filter'
import './expiation_show.scss'
const Expiation_show = () => {
  return (
    <div>Expiation_show</div>
  )
}

export default Expiation_show