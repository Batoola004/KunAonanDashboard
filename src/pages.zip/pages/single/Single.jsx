import React from 'react'

const Single = () => {
  return (
    <div className='single'>
        Single

    </div>
  )
}

export default Single