import React, { useState } from 'react';
import './login.scss';
import { useNavigate } from 'react-router-dom';

function Login3() {
  const navigate = useNavigate();
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState(null);
  const [shake, setShake] = useState(false);

  const handleSend = () => {
    if (!password || !confirmPassword) {
      setError("الرجاء إدخال كلمة المرور الجديدة");
      triggerShake();
      return;
    }

    if (password === confirmPassword) {
      navigate("/confirm");
    } else {
      setError("كلمة المرور غير متطابقة");
      triggerShake();
    }
  };

  const triggerShake = () => {
    setShake(true);
    setTimeout(() => setShake(false), 500);
  };

  return (
    <div className='login-container'>
      <div className='login-box'>
        <div className="form-side">
          <div className="input-group">
            <div className={shake ? 'shake' : ''}>
              <label htmlFor='password1'>كلمة المرور الجديدة:</label>
              <input 
                type="password" 
                id="password1" 
                placeholder="أدخل كلمة المرور الجديدة" 
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>
            <div className={shake ? 'shake' : ''}>
              <label htmlFor='password2'>تأكيد كلمة المرور:</label>
              <input 
                type="password" 
                id="password2" 
                placeholder="أكد كلمة المرور الجديدة" 
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
              />
            </div>
            {error && <p style={{ color: "red", marginTop: "5px" }}>{error}</p>}
            <button 
              className='login-btn' 
              onClick={handleSend}
            >
              تأكيد
            </button>
          </div>
        </div>
        <div className="logo-side">
          <img src="/assets/Kun_aonan.jpg" alt="logo" className="Logo" />
        </div>
      </div>
    </div>
  );
}

export default Login3;
